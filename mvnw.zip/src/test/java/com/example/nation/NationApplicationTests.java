package com.example.nation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NationApplicationTests {

	@Test
	void contextLoads() {
	}

}
